﻿using System.Collections;
using UnityEngine;

/// <summary>
/// Создаёт трубы и управляет прогрессивным усложнением игры.
///
/// Версия баланса:
/// - сложность повышается каждые 20 очков;
/// - движение труб вверх/вниз хорошо чувствуется;
/// - движущиеся трубы не уходят в нечестные крайние положения;
/// - генератор не создаёт резкие комбинации "низко -> высоко -> низко";
/// - suddenShift для движущихся труб отключён, потому что именно он создаёт ощущение нечестного рывка;
/// - ступенчатые серии появляются только в поздней игре;
/// - ступенчатая серия теперь продолжительная и строится как один читаемый паттерн:
///   либо "горка вверх" с нарастанием и спадом,
///   либо "яма вниз" со спадом и возвратом.
/// </summary>
public class Spawner : MonoBehaviour
{
    [Header("Префабы труб")]
    [Tooltip("Префаб дневных труб из рабочей версии.")]
    public Pipes dayPipesPrefab;

    [Tooltip("Префаб ночных труб из рабочей версии.")]
    public Pipes nightPipesPrefab;

    [Header("Базовый спавн")]
    [Tooltip("Базовая пауза между появлением труб.")]
    public float spawnRate = 1f;

    [Tooltip("Минимальное базовое смещение трубы по высоте.")]
    public float minHeight = -1f;

    [Tooltip("Максимальное базовое смещение трубы по высоте.")]
    public float maxHeight = 2f;

    [Tooltip("Базовый зазор между верхней и нижней трубой.")]
    public float verticalGap = 3f;

    [Header("Смена дня и ночи")]
    [Tooltip("Старый интервал смены дня и ночи. Используется только если SkySwitcher не найден или отключено чтение состояния SkySwitcher.")]
    public float switchInterval = 60f;

    [Tooltip("Если SkySwitcher найден, новые трубы берут состояние день/ночь из него.")]
    public bool useSkySwitcherStateWhenAvailable = true;

    [Tooltip("Контроллер смены дня/ночи. Если не назначен, будет найден автоматически.")]
    public SkySwitcher skySwitcher;

    [Header("Прогрессивная сложность")]
    [Tooltip("Включает усложнение по количеству успешных пролётов труб.")]
    public bool useScoreBasedDifficulty = true;

    [Tooltip("Через сколько очков повышается этап сложности.")]
    public int pointsPerDifficultyStage = 20;

    [Tooltip("Минимально допустимый статический gap, ниже которого обычные трубы не сужаются.")]
    public float minimumVerticalGap = 2.35f;

    [Tooltip("Минимальный gap во время динамического сужения/расширения.")]
    public float minimumDynamicGap = 2.25f;

    [Tooltip("Минимально допустимая пауза между обычными трубами.")]
    public float minimumSpawnDelay = 0.80f;

    [Tooltip("Показывать в консоли смену этапов сложности.")]
    public bool logDifficultyStageChanges = true;

    [Header("Fair Spawn Director")]
    [Tooltip("Если включено, Spawner ограничивает резкие перепады высоты между соседними трубами.")]
    public bool useFairSpawnDirector = true;

    [Tooltip("Насколько движущиеся трубы должны быть дальше от крайних верхних/нижних позиций.")]
    public float movingPipeHeightPadding = 0.35f;

    [Tooltip("Дополнительный gap для движущихся труб. Движущийся проход сложнее читать, поэтому ему нужен небольшой запас.")]
    public float movingPipeGapBonus = 0.12f;

    [Tooltip("Минимальная безопасная высота центра прохода в мировых координатах.")]
    public float safeWorldMinCenterY = -1.65f;

    [Tooltip("Максимальная безопасная высота центра прохода в мировых координатах.")]
    public float safeWorldMaxCenterY = 2.65f;

    [Tooltip("Сколько обычных труб должно пройти между ступенчатыми сериями.")]
    public int minimumPipesBetweenStaircases = 5;

    [Header("Ступенчатые серии поздней игры")]
    [Tooltip("Разрешить продолжительные серии близких труб в форме ступенек на позднем этапе.")]
    public bool enableStaircasePatterns = true;

    [Tooltip("Минимальное количество труб в ступенчатой серии.")]
    public int minStaircaseLength = 5;

    [Tooltip("Максимальное количество труб в ступенчатой серии.")]
    public int maxStaircaseLength = 7;

    [Tooltip("Вертикальный шаг между соседними трубами в ступенчатой серии.")]
    public float staircaseStepHeight = 0.45f;

    [Tooltip("Во сколько раз промежуток внутри ступенчатой серии короче обычного spawnRate текущего этапа.")]
    public float staircaseSpawnDelayMultiplier = 0.78f;

    [Tooltip("Минимальная пауза между трубами внутри ступенчатой серии.")]
    public float minimumStaircaseSpawnDelay = 0.58f;

    [Tooltip("После ступенчатой серии добавляется пауза, чтобы серия не слипалась со следующей трубой.")]
    public float staircaseRecoveryDelayMultiplier = 1.10f;

    private bool isDay = true;
    private float switchTimer;

    private Coroutine spawnLoopCoroutine;
    private int lastLoggedDifficultyStage = -1;

    private bool hasLastSpawnHeight;
    private float lastSpawnHeight;
    private int pipesSinceLastStaircase = 999;

    private void Awake()
    {
        if (skySwitcher == null)
        {
            skySwitcher = FindObjectOfType<SkySwitcher>();
        }
    }

    private void OnEnable()
    {
        if (spawnLoopCoroutine != null)
        {
            StopCoroutine(spawnLoopCoroutine);
        }

        spawnLoopCoroutine = StartCoroutine(SpawnLoop());
    }

    private void OnDisable()
    {
        if (spawnLoopCoroutine != null)
        {
            StopCoroutine(spawnLoopCoroutine);
            spawnLoopCoroutine = null;
        }
    }

    private void OnValidate()
    {
        pointsPerDifficultyStage = Mathf.Max(20, pointsPerDifficultyStage);

        minimumVerticalGap = Mathf.Max(2.2f, minimumVerticalGap);
        minimumDynamicGap = Mathf.Max(2.1f, minimumDynamicGap);
        minimumSpawnDelay = Mathf.Max(0.72f, minimumSpawnDelay);

        movingPipeHeightPadding = Mathf.Clamp(movingPipeHeightPadding, 0.15f, 0.75f);
        movingPipeGapBonus = Mathf.Clamp(movingPipeGapBonus, 0f, 0.35f);

        minimumPipesBetweenStaircases = Mathf.Max(0, minimumPipesBetweenStaircases);

        // Ступенчатая серия должна быть длиннее 3 труб,
        // но слишком длинная серия может превратиться в почти непрерывную стену.
        minStaircaseLength = Mathf.Clamp(minStaircaseLength, 5, 9);
        maxStaircaseLength = Mathf.Clamp(maxStaircaseLength, minStaircaseLength, 9);

        // Для серии с нарастанием и спадом шаг нельзя делать слишком большим:
        // при длине 7–9 труб высокий шаг быстро выводит паттерн к краям экрана.
        staircaseStepHeight = Mathf.Clamp(staircaseStepHeight, 0.25f, 0.60f);

        staircaseSpawnDelayMultiplier = Mathf.Clamp(staircaseSpawnDelayMultiplier, 0.65f, 1.15f);
        minimumStaircaseSpawnDelay = Mathf.Max(0.50f, minimumStaircaseSpawnDelay);
        staircaseRecoveryDelayMultiplier = Mathf.Max(1.00f, staircaseRecoveryDelayMultiplier);

        if (safeWorldMaxCenterY < safeWorldMinCenterY)
        {
            float temporary = safeWorldMinCenterY;
            safeWorldMinCenterY = safeWorldMaxCenterY;
            safeWorldMaxCenterY = temporary;
        }
    }

    private void Update()
    {
        UpdateFallbackDayNightTimer();
    }

    /// <summary>
    /// Основной цикл создания труб.
    /// Задержка пересчитывается каждый раз, поэтому сложность меняется без перезапуска игры.
    /// </summary>
    private IEnumerator SpawnLoop()
    {
        while (true)
        {
            DifficultySettings settings = GetCurrentDifficultySettings();

            yield return new WaitForSeconds(settings.spawnDelay);

            settings = GetCurrentDifficultySettings();
            LogDifficultyStageIfNeeded(settings.stage);

            if (ShouldSpawnStaircase(settings))
            {
                yield return StartCoroutine(SpawnStaircasePattern(settings));

                float recoveryDelay = Mathf.Max(
                    minimumStaircaseSpawnDelay,
                    settings.spawnDelay * staircaseRecoveryDelayMultiplier
                );

                yield return new WaitForSeconds(recoveryDelay);
            }
            else
            {
                bool isMovingPipe = IsMovingPipe(settings);
                float height = SelectFairHeight(settings, settings.minHeight, settings.maxHeight, isMovingPipe);
                SpawnSinglePipe(settings, height, false);
            }
        }
    }

    private void UpdateFallbackDayNightTimer()
    {
        if (useSkySwitcherStateWhenAvailable && skySwitcher != null)
        {
            return;
        }

        switchTimer += Time.deltaTime;

        if (switchTimer >= switchInterval)
        {
            switchTimer = 0f;
            isDay = !isDay;
        }
    }

    /// <summary>
    /// Создаёт одну пару труб и передаёт ей параметры сложности.
    /// </summary>
    private Pipes SpawnSinglePipe(DifficultySettings settings, float verticalOffset, bool isPartOfStaircase)
    {
        bool visualIsDay = GetCurrentDayNightVisualState();
        Pipes selectedPrefab = GetSelectedPrefab(visualIsDay);

        if (selectedPrefab == null)
        {
            Debug.LogError("Spawner: не назначен dayPipesPrefab или nightPipesPrefab.", this);
            return null;
        }

        bool isMovingPipe = IsMovingPipe(settings);
        float safeHeight = ClampHeightToFairRange(settings, verticalOffset, isMovingPipe);
        float effectiveGap = settings.verticalGap;

        if (isMovingPipe)
        {
            effectiveGap += settings.movingPipeGapBonus;
        }

        Vector3 spawnPosition = transform.position + Vector3.up * safeHeight;
        Pipes pipes = Instantiate(selectedPrefab, spawnPosition, Quaternion.identity);

        pipes.Configure(effectiveGap, skySwitcher);
        pipes.SetSprite(visualIsDay);

        float effectiveMinimumDynamicGap = settings.minimumDynamicGap;
        float effectiveMaximumDynamicGap = settings.maximumDynamicGap;

        if (isMovingPipe)
        {
            // Движущиеся трубы должны быть сложными за счёт движения,
            // а не за счёт слишком маленького прохода.
            effectiveMinimumDynamicGap = Mathf.Max(effectiveMinimumDynamicGap, effectiveGap - 0.14f);
            effectiveMaximumDynamicGap = Mathf.Max(effectiveMaximumDynamicGap, effectiveGap + 0.14f);
        }

        bool allowSuddenShiftForThisPipe =
            !isMovingPipe &&
            !isPartOfStaircase &&
            settings.enableSuddenShift &&
            Random.value <= settings.suddenShiftChance;

        pipes.ConfigureDifficulty(
            pipeSpeed: GetPipeSpeed(selectedPrefab, settings),

            newPassageMotionMode: settings.passageMotionMode,
            newCenterMoveAmplitude: settings.centerMoveAmplitude,
            newCenterMoveFrequency: settings.centerMoveFrequency,
            newCenterMovePhase: Random.Range(0f, Mathf.PI * 2f),
            newMaxCenterOffset: settings.maxCenterOffset,

            newGapMotionMode: settings.gapMotionMode,
            newMinimumDynamicGap: effectiveMinimumDynamicGap,
            newMaximumDynamicGap: effectiveMaximumDynamicGap,
            newGapPulseAmplitude: settings.gapPulseAmplitude,
            newGapPulseFrequency: settings.gapPulseFrequency,
            newGapPulsePhase: Random.Range(0f, Mathf.PI * 2f),

            allowSuddenShift: allowSuddenShiftForThisPipe,
            suddenMaxAmplitude: settings.suddenShiftAmplitude,
            suddenMinDelay: settings.suddenShiftMinDelay,
            suddenMaxDelay: settings.suddenShiftMaxDelay,
            maxSuddenShifts: settings.maxSuddenShifts,
            suddenLerpDuration: settings.suddenShiftDuration,
            allowSuddenShiftUntilX: settings.suddenShiftAllowedUntilX,

            newSafeWorldMinCenterY: safeWorldMinCenterY,
            newSafeWorldMaxCenterY: safeWorldMaxCenterY
        );

        RegisterSpawnHeight(safeHeight);

        return pipes;
    }

    /// <summary>
    /// Создаёт продолжительную ступенчатую серию.
    ///
    /// Важное отличие от предыдущего варианта:
    /// серия не является простой монотонной линией.
    /// Она строится как читаемый паттерн с нарастанием и спадом.
    ///
    /// Возможны только два типа:
    /// 1. "Горка вверх": 0 -> 1 -> 2 -> 3 -> 2 -> 1 -> 0.
    /// 2. "Яма вниз":   0 -> -1 -> -2 -> -3 -> -2 -> -1 -> 0.
    ///
    /// То есть внутри серии есть чередование ступеней и возврат,
    /// но общий тип направления один: либо вверх, либо вниз.
    ///
    /// Серия остаётся статичной:
    /// - без движения прохода;
    /// - без пульсации gap;
    /// - без suddenShift.
    ///
    /// Так игрок получает длинный и заметный паттерн, но не хаотичную ловушку.
    /// </summary>
    private IEnumerator SpawnStaircasePattern(DifficultySettings settings)
    {
        int minLength = Mathf.Clamp(minStaircaseLength, 5, 9);
        int maxLength = Mathf.Clamp(maxStaircaseLength, minLength, 9);
        int length = Random.Range(minLength, maxLength + 1);

        float stepHeight = Mathf.Clamp(staircaseStepHeight, 0.25f, 0.60f);

        // true  — "горка вверх": высоты сначала растут, потом снижаются;
        // false — "яма вниз": высоты сначала снижаются, потом возвращаются.
        bool directionIsUp = Random.value < 0.5f;
        float directionMultiplier = directionIsUp ? 1f : -1f;

        float[] heightOffsets = new float[length];

        for (int i = 0; i < length; i++)
        {
            // Формируем волну ступенек:
            // длина 5: 0, 1, 2, 1, 0
            // длина 6: 0, 1, 2, 2, 1, 0
            // длина 7: 0, 1, 2, 3, 2, 1, 0
            // длина 8: 0, 1, 2, 3, 3, 2, 1, 0
            // длина 9: 0, 1, 2, 3, 4, 3, 2, 1, 0
            int ascendingLevel = i;
            int descendingLevel = length - 1 - i;
            int level = Mathf.Min(ascendingLevel, descendingLevel);

            heightOffsets[i] = directionMultiplier * stepHeight * level;
        }

        float minOffset = heightOffsets[0];
        float maxOffset = heightOffsets[0];

        for (int i = 1; i < heightOffsets.Length; i++)
        {
            minOffset = Mathf.Min(minOffset, heightOffsets[i]);
            maxOffset = Mathf.Max(maxOffset, heightOffsets[i]);
        }

        // Подбираем базовую высоту так, чтобы вся серия помещалась в допустимый диапазон.
        // Это важно: длинная "горка" или "яма" не должна улететь за верх/низ экрана.
        float minBaseHeight = settings.minHeight - minOffset;
        float maxBaseHeight = settings.maxHeight - maxOffset;

        float baseHeight;

        if (minBaseHeight <= maxBaseHeight)
        {
            baseHeight = SelectFairHeight(settings, minBaseHeight, maxBaseHeight, false);
        }
        else
        {
            // Запасной вариант на случай слишком узкого диапазона:
            // ставим центр паттерна в центр допустимой области.
            float rangeCenter = (settings.minHeight + settings.maxHeight) * 0.5f;
            float offsetCenter = (minOffset + maxOffset) * 0.5f;
            baseHeight = rangeCenter - offsetCenter;
        }

        float internalDelay = Mathf.Max(
            minimumStaircaseSpawnDelay,
            settings.spawnDelay * staircaseSpawnDelayMultiplier
        );

        DifficultySettings patternSettings = settings;

        // Внутри ступенчатой серии трубы не двигаются.
        // Иначе паттерн перестанет быть читаемым.
        patternSettings.passageMotionMode = Pipes.PassageMotionMode.Static;
        patternSettings.centerMoveAmplitude = 0f;
        patternSettings.centerMoveFrequency = 1f;
        patternSettings.maxCenterOffset = 0f;

        // Gap внутри серии фиксированный.
        patternSettings.gapMotionMode = Pipes.GapMotionMode.Static;
        patternSettings.minimumDynamicGap = patternSettings.verticalGap;
        patternSettings.maximumDynamicGap = patternSettings.verticalGap;
        patternSettings.gapPulseAmplitude = 0f;
        patternSettings.gapPulseFrequency = 1f;

        // Резкие сдвиги внутри серии запрещены.
        patternSettings.enableSuddenShift = false;
        patternSettings.suddenShiftChance = 0f;
        patternSettings.maxSuddenShifts = 0;
        patternSettings.suddenShiftAmplitude = 0f;

        for (int i = 0; i < length; i++)
        {
            float height = baseHeight + heightOffsets[i];
            height = Mathf.Clamp(height, settings.minHeight, settings.maxHeight);

            SpawnSinglePipe(patternSettings, height, true);

            if (i < length - 1)
            {
                yield return new WaitForSeconds(internalDelay);
            }
        }

        pipesSinceLastStaircase = 0;

        Debug.Log(
            $"Spawner: создана ступенчатая серия. Тип: {(directionIsUp ? "горка вверх" : "яма вниз")}, длина: {length}, шаг: {stepHeight:F2}.",
            this
        );
    }

    /// <summary>
    /// Возвращает настройки текущей сложности.
    ///
    /// Баланс:
    /// 0–19   — базовая игра;
    /// 20–39  — ускорение без движения;
    /// 40–59  — заметное движение труб;
    /// 60–79  — более выраженное движение + мягкая пульсация gap;
    /// 80+    — поздняя игра с активным движением и редкими ступенями.
    /// </summary>
    private DifficultySettings GetCurrentDifficultySettings()
    {
        int stage = useScoreBasedDifficulty ? GetDifficultyStageFromScore() : 0;
        DifficultySettings settings = CreateBaseDifficultySettings(stage);

        switch (stage)
        {
            case 0:
                // 0–19 очков: базовая рабочая версия.
                break;

            case 1:
                // 20–39 очков: игрок уже освоился, можно ускорить игру,
                // но движение труб ещё не включаем.
                settings.spawnDelay = spawnRate * 0.94f;
                settings.verticalGap = verticalGap * 0.94f;
                settings.minHeight = minHeight - 0.12f;
                settings.maxHeight = maxHeight + 0.12f;
                settings.speedMultiplier = 1.07f;
                break;

            case 2:
                // 40–59 очков: движение труб должно чувствоваться.
                // Оно уже заметное, но не уводит проход в крайние зоны.
                settings.spawnDelay = spawnRate * 0.90f;
                settings.verticalGap = verticalGap * 0.90f;
                settings.minHeight = minHeight - 0.22f;
                settings.maxHeight = maxHeight + 0.22f;
                settings.speedMultiplier = 1.12f;

                settings.passageMotionMode = Pipes.PassageMotionMode.SmoothSine;
                settings.centerMoveAmplitude = 0.38f;
                settings.centerMoveFrequency = 1.05f;
                settings.maxCenterOffset = 0.56f;
                settings.movingPipeGapBonus = movingPipeGapBonus;
                break;

            case 3:
                // 60–79 очков: движение сильнее и живее.
                // Gap слегка пульсирует, но suddenShift не используется,
                // чтобы не было нечестного рывка прямо перед игроком.
                settings.spawnDelay = spawnRate * 0.86f;
                settings.verticalGap = verticalGap * 0.87f;
                settings.minHeight = minHeight - 0.30f;
                settings.maxHeight = maxHeight + 0.30f;
                settings.speedMultiplier = 1.17f;

                settings.passageMotionMode = Pipes.PassageMotionMode.SmoothPingPong;
                settings.centerMoveAmplitude = 0.48f;
                settings.centerMoveFrequency = 1.05f;
                settings.maxCenterOffset = 0.68f;
                settings.movingPipeGapBonus = movingPipeGapBonus + 0.03f;

                settings.gapMotionMode = Pipes.GapMotionMode.SmoothPulse;
                settings.minimumDynamicGap = settings.verticalGap - 0.12f;
                settings.maximumDynamicGap = settings.verticalGap + 0.16f;
                settings.gapPulseAmplitude = 0.12f;
                settings.gapPulseFrequency = 1.05f;
                break;

            default:
                // 80+ очков: сложность должна ощущаться, но не становиться рандомной.
                // Движение активное, но ограниченное safeWorldMinCenterY/safeWorldMaxCenterY.
                settings.spawnDelay = spawnRate * 0.82f;
                settings.verticalGap = verticalGap * 0.84f;
                settings.minHeight = minHeight - 0.36f;
                settings.maxHeight = maxHeight + 0.36f;
                settings.speedMultiplier = 1.22f;

                settings.passageMotionMode = Pipes.PassageMotionMode.SmoothSine;
                settings.centerMoveAmplitude = 0.58f;
                settings.centerMoveFrequency = 1.20f;
                settings.maxCenterOffset = 0.78f;
                settings.movingPipeGapBonus = movingPipeGapBonus + 0.06f;

                settings.gapMotionMode = Pipes.GapMotionMode.SmoothPulse;
                settings.minimumDynamicGap = settings.verticalGap - 0.14f;
                settings.maximumDynamicGap = settings.verticalGap + 0.18f;
                settings.gapPulseAmplitude = 0.14f;
                settings.gapPulseFrequency = 1.12f;

                // SuddenShift оставлен выключенным.
                // Движение труб теперь достаточно заметное само по себе.
                settings.enableSuddenShift = false;
                settings.suddenShiftChance = 0f;
                settings.maxSuddenShifts = 0;
                settings.suddenShiftAmplitude = 0f;

                settings.allowStaircasePattern = enableStaircasePatterns;
                settings.staircaseChance = 0.16f;
                break;
        }

        ApplySafetyLimits(ref settings);
        return settings;
    }

    private DifficultySettings CreateBaseDifficultySettings(int stage)
    {
        DifficultySettings settings = new DifficultySettings();

        settings.stage = stage;

        settings.spawnDelay = spawnRate;
        settings.verticalGap = verticalGap;
        settings.minHeight = minHeight;
        settings.maxHeight = maxHeight;
        settings.speedMultiplier = 1f;

        settings.passageMotionMode = Pipes.PassageMotionMode.Static;
        settings.centerMoveAmplitude = 0f;
        settings.centerMoveFrequency = 1f;
        settings.maxCenterOffset = 0f;
        settings.movingPipeGapBonus = 0f;

        settings.gapMotionMode = Pipes.GapMotionMode.Static;
        settings.minimumDynamicGap = verticalGap;
        settings.maximumDynamicGap = verticalGap;
        settings.gapPulseAmplitude = 0f;
        settings.gapPulseFrequency = 1f;

        settings.enableSuddenShift = false;
        settings.suddenShiftChance = 0f;
        settings.maxSuddenShifts = 0;
        settings.suddenShiftAmplitude = 0f;
        settings.suddenShiftMinDelay = 0.45f;
        settings.suddenShiftMaxDelay = 1.1f;
        settings.suddenShiftDuration = 0.18f;
        settings.suddenShiftAllowedUntilX = 3.5f;

        settings.allowStaircasePattern = false;
        settings.staircaseChance = 0f;

        return settings;
    }

    /// <summary>
    /// Защитный слой баланса.
    /// Он не делает игру детской, но не даёт параметрам уйти в нечестные значения.
    /// </summary>
    private void ApplySafetyLimits(ref DifficultySettings settings)
    {
        settings.spawnDelay = Mathf.Max(GetRecommendedMinimumSpawnDelay(settings.stage), settings.spawnDelay, minimumSpawnDelay);
        settings.verticalGap = Mathf.Max(GetRecommendedMinimumGap(settings.stage), settings.verticalGap, minimumVerticalGap);

        if (settings.maxHeight < settings.minHeight)
        {
            float temporary = settings.minHeight;
            settings.minHeight = settings.maxHeight;
            settings.maxHeight = temporary;
        }

        settings.minHeight = Mathf.Max(settings.minHeight, safeWorldMinCenterY + 0.08f);
        settings.maxHeight = Mathf.Min(settings.maxHeight, safeWorldMaxCenterY - 0.08f);

        if (settings.maxHeight < settings.minHeight)
        {
            float center = (safeWorldMinCenterY + safeWorldMaxCenterY) * 0.5f;
            settings.minHeight = center - 0.5f;
            settings.maxHeight = center + 0.5f;
        }

        if (settings.gapMotionMode == Pipes.GapMotionMode.Static)
        {
            settings.minimumDynamicGap = settings.verticalGap;
            settings.maximumDynamicGap = settings.verticalGap;
            settings.gapPulseAmplitude = 0f;
        }
        else
        {
            settings.minimumDynamicGap = Mathf.Max(
                minimumDynamicGap,
                settings.verticalGap - 0.18f,
                settings.minimumDynamicGap
            );

            settings.maximumDynamicGap = Mathf.Max(
                settings.minimumDynamicGap,
                settings.maximumDynamicGap
            );

            settings.gapPulseAmplitude = Mathf.Min(settings.gapPulseAmplitude, 0.16f);
        }

        if (IsMovingPipe(settings))
        {
            // Движение должно быть заметным, но не должно выводить проход за пределы нормального прохождения.
            settings.centerMoveAmplitude = Mathf.Min(settings.centerMoveAmplitude, 0.62f);
            settings.maxCenterOffset = Mathf.Min(settings.maxCenterOffset, 0.82f);
            settings.centerMoveFrequency = Mathf.Min(settings.centerMoveFrequency, 1.25f);

            // Резкие скачки у движущихся труб запрещены.
            settings.enableSuddenShift = false;
            settings.suddenShiftChance = 0f;
            settings.maxSuddenShifts = 0;
            settings.suddenShiftAmplitude = 0f;
        }
    }

    private float GetRecommendedMinimumSpawnDelay(int stage)
    {
        if (stage <= 0)
        {
            return 0.95f;
        }

        if (stage == 1)
        {
            return 0.90f;
        }

        if (stage == 2)
        {
            return 0.86f;
        }

        if (stage == 3)
        {
            return 0.82f;
        }

        return 0.80f;
    }

    private float GetRecommendedMinimumGap(int stage)
    {
        if (stage <= 0)
        {
            return 2.80f;
        }

        if (stage == 1)
        {
            return 2.70f;
        }

        if (stage == 2)
        {
            return 2.58f;
        }

        if (stage == 3)
        {
            return 2.45f;
        }

        return 2.36f;
    }

    /// <summary>
    /// Выбирает честную высоту трубы.
    /// Ограничивает резкие перепады между соседними препятствиями.
    /// </summary>
    private float SelectFairHeight(DifficultySettings settings, float requestedMin, float requestedMax, bool isMovingPipe)
    {
        float min = Mathf.Min(requestedMin, requestedMax);
        float max = Mathf.Max(requestedMin, requestedMax);

        if (!useFairSpawnDirector)
        {
            return SafeRandomRange(min, max);
        }

        if (isMovingPipe)
        {
            float paddedMin = min + movingPipeHeightPadding;
            float paddedMax = max - movingPipeHeightPadding;

            if (paddedMin <= paddedMax)
            {
                min = paddedMin;
                max = paddedMax;
            }
        }

        if (hasLastSpawnHeight)
        {
            float maxDelta = GetMaxHeightDelta(settings.stage, isMovingPipe);
            min = Mathf.Max(min, lastSpawnHeight - maxDelta);
            max = Mathf.Min(max, lastSpawnHeight + maxDelta);
        }

        if (max < min)
        {
            float fallback = hasLastSpawnHeight
                ? Mathf.Clamp(lastSpawnHeight, requestedMin, requestedMax)
                : (requestedMin + requestedMax) * 0.5f;

            return fallback;
        }

        float candidate = SafeRandomRange(min, max);

        if (hasLastSpawnHeight)
        {
            candidate = PreventOppositeExtremeJump(candidate, settings, isMovingPipe);
        }

        return Mathf.Clamp(candidate, requestedMin, requestedMax);
    }

    private float ClampHeightToFairRange(DifficultySettings settings, float height, bool isMovingPipe)
    {
        float min = settings.minHeight;
        float max = settings.maxHeight;

        if (isMovingPipe)
        {
            float paddedMin = min + movingPipeHeightPadding;
            float paddedMax = max - movingPipeHeightPadding;

            if (paddedMin <= paddedMax)
            {
                min = paddedMin;
                max = paddedMax;
            }
        }

        if (hasLastSpawnHeight && useFairSpawnDirector)
        {
            float maxDelta = GetMaxHeightDelta(settings.stage, isMovingPipe);
            min = Mathf.Max(min, lastSpawnHeight - maxDelta);
            max = Mathf.Min(max, lastSpawnHeight + maxDelta);
        }

        if (max < min)
        {
            return Mathf.Clamp(height, settings.minHeight, settings.maxHeight);
        }

        return Mathf.Clamp(height, min, max);
    }

    /// <summary>
    /// Запрещает скачок из крайнего низа в крайний верх и наоборот.
    /// </summary>
    private float PreventOppositeExtremeJump(float candidate, DifficultySettings settings, bool isMovingPipe)
    {
        float range = Mathf.Max(0.01f, settings.maxHeight - settings.minHeight);
        float lowerExtreme = settings.minHeight + range * 0.24f;
        float upperExtreme = settings.maxHeight - range * 0.24f;
        float center = (settings.minHeight + settings.maxHeight) * 0.5f;
        float centerBand = isMovingPipe ? range * 0.14f : range * 0.20f;

        bool lastWasLow = lastSpawnHeight <= lowerExtreme;
        bool lastWasHigh = lastSpawnHeight >= upperExtreme;

        if (lastWasLow && candidate >= upperExtreme)
        {
            return SafeRandomRange(center - centerBand, center + centerBand);
        }

        if (lastWasHigh && candidate <= lowerExtreme)
        {
            return SafeRandomRange(center - centerBand, center + centerBand);
        }

        return candidate;
    }

    private float GetMaxHeightDelta(int stage, bool isMovingPipe)
    {
        float maxDelta;

        if (stage <= 0)
        {
            maxDelta = 1.05f;
        }
        else if (stage == 1)
        {
            maxDelta = 1.14f;
        }
        else if (stage == 2)
        {
            maxDelta = 1.24f;
        }
        else if (stage == 3)
        {
            maxDelta = 1.34f;
        }
        else
        {
            maxDelta = 1.42f;
        }

        if (isMovingPipe)
        {
            maxDelta -= 0.16f;
        }

        return Mathf.Max(0.85f, maxDelta);
    }

    private void RegisterSpawnHeight(float height)
    {
        lastSpawnHeight = height;
        hasLastSpawnHeight = true;
        pipesSinceLastStaircase++;
    }

    private bool IsMovingPipe(DifficultySettings settings)
    {
        return settings.passageMotionMode != Pipes.PassageMotionMode.Static;
    }

    private int GetDifficultyStageFromScore()
    {
        int safeStep = Mathf.Max(20, pointsPerDifficultyStage);
        int currentScore = 0;

        if (GameManager.Instance != null)
        {
            currentScore = GameManager.Instance.score;
        }

        return Mathf.Max(0, currentScore / safeStep);
    }

    private bool ShouldSpawnStaircase(DifficultySettings settings)
    {
        if (!settings.allowStaircasePattern)
        {
            return false;
        }

        if (pipesSinceLastStaircase < minimumPipesBetweenStaircases)
        {
            return false;
        }

        return Random.value <= settings.staircaseChance;
    }

    private float GetPipeSpeed(Pipes prefab, DifficultySettings settings)
    {
        float baseSpeed = prefab != null ? prefab.speed : 5f;
        return Mathf.Max(0.1f, baseSpeed * settings.speedMultiplier);
    }

    private bool GetCurrentDayNightVisualState()
    {
        if (useSkySwitcherStateWhenAvailable && skySwitcher != null)
        {
            return skySwitcher.IsDay;
        }

        return isDay;
    }

    private Pipes GetSelectedPrefab(bool visualIsDay)
    {
        Pipes preferredPrefab = visualIsDay ? dayPipesPrefab : nightPipesPrefab;

        if (preferredPrefab != null)
        {
            return preferredPrefab;
        }

        return visualIsDay ? nightPipesPrefab : dayPipesPrefab;
    }

    private float SafeRandomRange(float min, float max)
    {
        if (max < min)
        {
            float temporary = min;
            min = max;
            max = temporary;
        }

        if (Mathf.Approximately(min, max))
        {
            return min;
        }

        return Random.Range(min, max);
    }

    private void LogDifficultyStageIfNeeded(int stage)
    {
        if (!logDifficultyStageChanges)
        {
            return;
        }

        if (stage == lastLoggedDifficultyStage)
        {
            return;
        }

        lastLoggedDifficultyStage = stage;

        int currentScore = GameManager.Instance != null ? GameManager.Instance.score : 0;
        int safeStep = Mathf.Max(20, pointsPerDifficultyStage);
        int fromScore = stage * safeStep;
        int toScore = fromScore + safeStep - 1;

        Debug.Log($"Spawner: активен этап сложности {stage}. Score: {currentScore}. Диапазон этапа: {fromScore}–{toScore}.", this);
    }

    private struct DifficultySettings
    {
        public int stage;

        public float spawnDelay;
        public float verticalGap;
        public float minHeight;
        public float maxHeight;
        public float speedMultiplier;

        public Pipes.PassageMotionMode passageMotionMode;
        public float centerMoveAmplitude;
        public float centerMoveFrequency;
        public float maxCenterOffset;
        public float movingPipeGapBonus;

        public Pipes.GapMotionMode gapMotionMode;
        public float minimumDynamicGap;
        public float maximumDynamicGap;
        public float gapPulseAmplitude;
        public float gapPulseFrequency;

        public bool enableSuddenShift;
        public float suddenShiftChance;
        public int maxSuddenShifts;
        public float suddenShiftAmplitude;
        public float suddenShiftMinDelay;
        public float suddenShiftMaxDelay;
        public float suddenShiftDuration;
        public float suddenShiftAllowedUntilX;

        public bool allowStaircasePattern;
        public float staircaseChance;
    }
}